/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sms.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author M U N Y I N Y A
 */
@Entity
public class NewClass {
   @Id
    private int id;
    private String names;

    public NewClass() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }
    
}
