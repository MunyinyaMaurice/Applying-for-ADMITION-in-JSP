/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sms.service;

import com.sms.model.AdmissionModel;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 *
 * @author M U N Y I N Y A
 */
public interface StudentAdmissionInterface extends Remote{
     public boolean saveStudents(AdmissionModel student) throws RemoteException;
    public void updateStudents(AdmissionModel student) throws RemoteException;
    public void deleteStudents(AdmissionModel student) throws RemoteException;
    public List<AdmissionModel> getStudent() throws RemoteException;
    public AdmissionModel getStudentEmail(String email) throws RemoteException;
}
