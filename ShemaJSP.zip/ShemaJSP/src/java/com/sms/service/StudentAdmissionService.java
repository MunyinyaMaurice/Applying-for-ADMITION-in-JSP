/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sms.service;

import com.sms.dao.StudentAdmissionDao;
import com.sms.model.AdmissionModel;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 *
 * @author M U N Y I N Y A
 */
public class StudentAdmissionService extends UnicastRemoteObject implements StudentAdmissionInterface{
  StudentAdmissionDao studentDao = new StudentAdmissionDao();

    public StudentAdmissionService() throws RemoteException {
        super();
    }

    @Override
    public boolean saveStudents(AdmissionModel student) throws RemoteException {
return studentDao.createStudent(student);
      
    }

    @Override
    public void updateStudents(AdmissionModel student) throws RemoteException {
       studentDao.updateStudent(student);
    }

    @Override
    public void deleteStudents(AdmissionModel student) throws RemoteException {
       studentDao.deleteStudent(student);
    }

    @Override
    public List<AdmissionModel> getStudent() throws RemoteException {
         return studentDao.findAl();
    }

    @Override
    public AdmissionModel getStudentEmail(String email) throws RemoteException {
        return studentDao.findStudents(email);
    }

   
}
