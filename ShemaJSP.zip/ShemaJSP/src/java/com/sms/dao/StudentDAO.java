/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sms.dao;

import com.sms.model.AdmissionModel;
import com.sms.model.Student;
import java.util.ArrayList;
import java.util.List;
//import javax.websocket.Session;
import org.hibernate.*;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author hnjej
 */
public class StudentDAO {

    public static boolean createStudent(Student student) {
        boolean result = false;
        Session session = FactoryManager.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(student);
        tx.commit();
        session.close();
        result = Boolean.TRUE;
        return result;
    }

    public boolean updateStudent(Student student) {
        boolean result = false;
        Session session = FactoryManager.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.createQuery("update Student set contact="+student.getContact()+", email='"+student.getEmail()+"', password="+student.getPassword()+", userName="+student.getUserName()+" where email='"+student.getEmail()+"'");
        tx.commit();
        session.close();
        result = Boolean.TRUE;
        return result;
    }

    public List<Student> findAll() {
        Session session = null;
        List<Student> result = new ArrayList<>();
        try {
            session = FactoryManager.getSessionFactory().openSession();
            result = session.createQuery("from Student").list();
        } catch (HibernateException ex) {
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return result;

    }

    public Student findStudent(String email) {
        Session session = null;
        Student result = null;
        try {
            session = FactoryManager.getSessionFactory().openSession();
            Criteria criteria = session.createCriteria(Student.class);
            criteria.add(Restrictions.eq("email", email));

            result = (Student) criteria.uniqueResult();
        } catch (HibernateException ex) {
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return result;
    }

    public void deleteStudent(Student student) {
        Session session = FactoryManager.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.createQuery("delete from Student where email='"+student.getEmail()+"'");
        tx.commit();
        session.close();
    }
    
//    public static void main(String[] args) {
//        StudentDAO dao = new StudentDAO();
//        Student st = new Student("emails@gmail.com","Username","45","contact");
//        dao.deleteStudent(st);
//        
//        System.out.println("deleted.");
//    }

   
}
