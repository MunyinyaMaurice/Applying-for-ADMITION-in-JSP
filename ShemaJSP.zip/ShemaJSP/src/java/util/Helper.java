/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 *
 * @author YES TECHNOLOGY
 */
public class Helper {
    
    // Static variable reference of single_instance
    // of type Singleton
    private static Helper single_instance ;
  
    // Declaring a variable of type String
     public String s;
     public ResourceBundle resourceBundle = ResourceBundle.getBundle("resources.content",new Locale("en","US")); 
    public static synchronized Helper getInstance()
    {
        if (single_instance == null)
            single_instance = new Helper();
  
        return single_instance;
    }
    
    public ResourceBundle setResource(String content,Locale local){
        resourceBundle = ResourceBundle.getBundle("resources.content", local);
        return resourceBundle;
    }
}
