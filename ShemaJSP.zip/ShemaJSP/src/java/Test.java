
import com.sms.dao.StudentDAO;
import com.sms.model.Student;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M U N Y I N Y A
 */
public class Test {
    public static void main(String[] args) {
        Student stud = new Student("munyinya@gmail.com", "Munyinya", "Shema", "3224");
        StudentDAO dao =  new StudentDAO();
        dao.createStudent(stud);
        System.out.println("Done!!");
    }  
}
